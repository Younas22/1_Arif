            <!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">All Subscription</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right d-none">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                                        href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li><a class="parent-item" href="">Subscription</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">All Subscription</li>
                            </ol>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card card-box">
                                <div class="card-head">
                                    <header>All Subscription</header>
                                    <div class="tools">
                                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                                        <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                                        <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                                    </div>
                                </div>
                                <div class="card-body ">
                                    <div class="table-scrollable">
                                        <table class="table table-hover table-checkable order-column full-width"
                                            id="example4">
                                            <thead>
                                                <tr>
                                                    <th class="center"> # </th>
                                                    <th class="center"> Email </th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <?php $count=1; foreach ($subscription as $key) { ?>
                                                <tr class="odd gradeX">
                                                    <td class="center"><?=$count?></td>
                                                    <td class="center"><?=$key->email?></td>
                                                </tr>
                                                <?php $count++; } ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end page content -->